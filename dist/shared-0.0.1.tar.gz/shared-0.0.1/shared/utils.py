def add_two_numbers(a: int, b: int):
    return a + b
