def example_function():
    return "Example function"
